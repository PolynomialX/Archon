#ifndef ARCHON_GENERAL_FILE_HPP_
#define ARCHON_GENERAL_FILE_HPP_
#include <string>
/**
 * @class File
 *        Abstract interface class that defines
 *        The interface for a general file.
 */
template<typename T>
class File
{
    /**
     * @brief write
     *        Method to write the contents of a '
     */
    virtual bool write(const std::string& fileName_) = 0;

    virtual bool read(const std::string& fileName_) = 0;
};

#endif // ARCHON_GENERAL_FILE_HPP_